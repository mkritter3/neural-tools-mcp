"""L9 GraphRAG - Graph Retrieval Augmented Generation System"""

__version__ = "1.0.0"
__author__ = "L9 Engineering"
__description__ = "Production-ready GraphRAG implementation with Neo4j and Qdrant"